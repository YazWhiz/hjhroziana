Ext.define('MyApp.Global', {
    singleton: true,

    config: {
        myurl: 'http://mhds.diskstation.me/HjhRoziana/php/'
    }
});