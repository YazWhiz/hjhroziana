# theme-triton-f156c2ed-b887-4c6f-b698-12c37ee9ea40/sass/var

This folder contains variable declaration files named by their component class.
