Ext.namespace('Ext.theme.is')['theme-triton-f156c2ed-b887-4c6f-b698-12c37ee9ea40'] = true;
Ext.theme.name = 'theme-triton-f156c2ed-b887-4c6f-b698-12c37ee9ea40';