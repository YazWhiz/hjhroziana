# theme-triton-ab5117a4-d227-497f-80c4-3da3f7153238/resources

This folder contains static resources (typically an `"images"` folder as well).
