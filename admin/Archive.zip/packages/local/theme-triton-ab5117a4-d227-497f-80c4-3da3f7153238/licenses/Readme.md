# theme-triton-ab5117a4-d227-497f-80c4-3da3f7153238/licenses

This folder contains the supported licenses for third-party use.
