# theme-triton-ab5117a4-d227-497f-80c4-3da3f7153238/sass/etc

This folder contains miscellaneous SASS files. Unlike `"theme-triton-ab5117a4-d227-497f-80c4-3da3f7153238/sass/etc"`, these files
need to be used explicitly.
