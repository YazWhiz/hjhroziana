# theme-triton-ab5117a4-d227-497f-80c4-3da3f7153238/sass/var

This folder contains variable declaration files named by their component class.
