# theme-neptune-e336f44d-9c11-4c0e-b7dd-b6d5c9d1d58c/resources

This folder contains static resources (typically an `"images"` folder as well).
