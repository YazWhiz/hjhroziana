# theme-crisp-77297b7e-2074-4690-b219-91a52fa5517f/sass/var

This folder contains variable declaration files named by their component class.
