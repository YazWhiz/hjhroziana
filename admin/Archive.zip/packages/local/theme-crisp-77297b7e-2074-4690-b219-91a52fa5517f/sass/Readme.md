# theme-crisp-77297b7e-2074-4690-b219-91a52fa5517f/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    theme-crisp-77297b7e-2074-4690-b219-91a52fa5517f/sass/etc
    theme-crisp-77297b7e-2074-4690-b219-91a52fa5517f/sass/src
    theme-crisp-77297b7e-2074-4690-b219-91a52fa5517f/sass/var
