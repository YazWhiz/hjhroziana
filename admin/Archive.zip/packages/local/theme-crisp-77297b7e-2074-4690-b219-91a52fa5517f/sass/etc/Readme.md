# theme-crisp-77297b7e-2074-4690-b219-91a52fa5517f/sass/etc

This folder contains miscellaneous SASS files. Unlike `"theme-crisp-77297b7e-2074-4690-b219-91a52fa5517f/sass/etc"`, these files
need to be used explicitly.
