# theme-crisp-77297b7e-2074-4690-b219-91a52fa5517f/overrides

This folder contains overrides which will automatically be required by package users.
